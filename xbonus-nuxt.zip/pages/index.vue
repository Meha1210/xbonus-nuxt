<template>
  <div>
    <Header />
    <main>
      <Hero />

      <section id="kampanyalar" class="container mx-auto px-4 py-12">
        <h3 class="text-2xl font-bold mb-4">Öne Çıkan Kampanyalar</h3>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div class="p-6 border rounded-lg">
            <h4 class="font-semibold mb-2">Deneme Bonusu</h4>
            <p>444 freespin ile ₺1.000'e kadar deneme bonusu.</p>
          </div>
          <div class="p-6 border rounded-lg">
            <h4 class="font-semibold mb-2">Yatırım Bonusu</h4>
            <p>İlk yatırımınıza özel %50 bonus.</p>
          </div>
          <div class="p-6 border rounded-lg">
            <h4 class="font-semibold mb-2">Haftalık Çekiliş</h4>
            <p>Her hafta ödüllü çekilişler.</p>
          </div>
        </div>
      </section>

      <section id="iletisim" class="container mx-auto px-4 py-12">
        <h3 class="text-2xl font-bold mb-4">İletişim</h3>
        <p>Destek için: <a href="mailto:destek@xbonus.example" class="underline">destek@xbonus.example</a></p>
      </section>
    </main>
    <Footer />
  </div>
</template>

<script setup lang="ts">
import Header from '~/components/Header.vue'
import Hero from '~/components/Hero.vue'
import Footer from '~/components/Footer.vue'
</script>