import { defineNuxtConfig } from 'nuxt'

export default defineNuxtConfig({
  ssr: true,
  css: ['~/assets/css/tailwind.css'],
  modules: ['@nuxtjs/tailwindcss'],
  app: {
    head: {
      title: 'XBONUS',
      meta: [
        { name: 'description', content: 'XBonus - Özel bonuslar ve kampanyalar' }
      ]
    }
  }
})