<template>
  <section class="py-20 bg-gradient-to-r from-sky-600 to-indigo-600 text-white">
    <div class="container mx-auto px-4 text-center">
      <h2 class="text-4xl font-extrabold mb-4">Yenilenen Deneme Bonusu ile Kazanmaya Başla</h2>
      <p class="mb-6 max-w-2xl mx-auto">444 freespin ile ₺1.000'e kadar kazan — güvenli çekim ve XBONUS güvencesiyle.</p>
      <div class="flex justify-center gap-3">
        <NuxtLink to="#" class="px-6 py-3 rounded-lg bg-white text-sky-700 font-semibold">Hemen Katıl</NuxtLink>
        <NuxtLink to="#" class="px-6 py-3 rounded-lg border border-white">Kampanyalar</NuxtLink>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts"></script>