<template>
  <header class="w-full py-4 shadow-md bg-white">
    <div class="container mx-auto px-4 flex items-center justify-between">
      <h1 class="text-xl font-bold">XBONUS</h1>
      <nav class="space-x-4">
        <NuxtLink to="#" class="hover:underline">Ana Sayfa</NuxtLink>
        <NuxtLink to="#kampanyalar" class="hover:underline">Kampanyalar</NuxtLink>
        <NuxtLink to="#iletisim" class="hover:underline">İletişim</NuxtLink>
      </nav>
    </div>
  </header>
</template>

<script setup lang="ts"></script>