<template>
  <footer class="py-6 bg-gray-800 text-gray-300">
    <div class="container mx-auto px-4 text-center">
      <p>© {{ new Date().getFullYear() }} XBONUS — Tüm hakları saklıdır.</p>
    </div>
  </footer>
</template>

<script setup lang="ts"></script>