# XBONUS Nuxt Starter

## Kurulum

1. Node.js >= 18 kurulu olmalı.
2. `npm install`
3. `npm run dev` ile geliştirme sunucusunu başlatın.
4. Vercel'e deploy için `vercel` CLI veya GitHub bağlantısı kullanabilirsiniz.
